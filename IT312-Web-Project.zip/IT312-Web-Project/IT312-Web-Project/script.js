
function initThemes() {
    const themeToggle = document.getElementById('theme-toggle');
    const currentTheme = localStorage.getItem('theme') || 'light';
    
    document.body.setAttribute('data-theme', currentTheme);
    
    if (themeToggle) {
        updateThemeButton(themeToggle, currentTheme);
        
        themeToggle.addEventListener('click', () => {
            const currentTheme = document.body.getAttribute('data-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            
            document.body.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            
            updateThemeButton(themeToggle, newTheme);
        });
    }
}

function updateThemeButton(button, theme) {
    button.textContent = theme === 'light' ? '🌙' : '☀️';
    button.title = theme === 'light' ? 'Switch to Dark Mode' : 'Switch to Light Mode';
}

function initBackToTop() {
    const backToTopBtn = document.getElementById('back-to-top');
    
    if (backToTopBtn) {
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                backToTopBtn.style.display = 'block';
            } else {
                backToTopBtn.style.display = 'none';
            }
        });
        
        backToTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
}

function initRealTimeClock() {
    const clockElement = document.getElementById('real-time-clock');
    
    if (clockElement) {
        function updateClock() {
            const now = new Date();
            const timeString = now.toLocaleTimeString('en-US', { 
                hour12: true,
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
            clockElement.textContent = timeString;
        }
        
        updateClock();
        setInterval(updateClock, 1000);
    }
}

function initServicesSorting() {
    const sortSelect = document.getElementById('sort-activities');
    const activityList = document.getElementById('activities-container');
    
    if (!sortSelect || !activityList) {
        return;
    }
    
    shuffleActivities();
    
    sortSelect.addEventListener('change', function() {
        sortActivities(this.value);
    });
}

function sortActivities(sortBy) {
    const activityList = document.getElementById('activities-container');
    const activities = Array.from(activityList.querySelectorAll('.activity-card'));
    
    if (sortBy === 'name') { 
        activities.sort((a, b) => {
            const nameA = a.querySelector('h3').textContent.toLowerCase();
            const nameB = b.querySelector('h3').textContent.toLowerCase();
            return nameA.localeCompare(nameB);
        });
    } else if (sortBy === 'price') {
        activities.sort((a, b) => {
            const priceA = parseInt(a.querySelector('.price').textContent) || 0;
            const priceB = parseInt(b.querySelector('.price').textContent) || 0;
            return priceA - priceB;
        });
    }
    
    activityList.innerHTML = '';
    activities.forEach(activity => {
        activityList.appendChild(activity);
    });
}

function shuffleActivities() {
    const activityList = document.getElementById('activities-container');
    if (!activityList) return;
    
    const activities = Array.from(activityList.querySelectorAll('.activity-card'));
    const shuffled = [...activities].sort(() => Math.random() - 0.5);
    
    activityList.innerHTML = '';
    shuffled.forEach(activity => {
        activityList.appendChild(activity);
    });
}

function initJoinTeamValidation() {
    const joinForm = document.querySelector('.join-form');
    
    if (joinForm) {
        joinForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('name')?.value.trim();
            const dob = document.getElementById('dob')?.value;
            const email = document.getElementById('email')?.value.trim();
            const photo = document.getElementById('photo-upload')?.files[0];
            const expertise = document.getElementById('expertise')?.value.trim();
            const skills = document.getElementById('skills-text')?.value.trim();
            const education = document.getElementById('education-text')?.value.trim();
            
            let errors = [];
            
            if (!name) errors.push('Name is required');
            if (!dob) errors.push('Date of Birth is required');
            if (!email) errors.push('Email is required');
            if (!photo) errors.push('Photo is required');
            if (!expertise) errors.push('Area of Expertise is required');
            if (!skills) errors.push('Skills are required');
            if (!education) errors.push('Education is required');
            
            if (errors.length > 0) {
                alert('Please fix the following errors:\n' + errors.join('\n'));
                return;
            }
            
            if (/^\d/.test(name)) {
                alert('Name cannot start with numbers.');
                return;
            }
            
            if (!photo.type.startsWith('image/')) {
                alert('Please upload an image file.');
                return;
            }
            
            const dobDate = new Date(dob);
            const maxDob = new Date('2008-12-31');
            if (dobDate > maxDob) {
                alert('Date of Birth must be before 2009.');
                return;
            }
            
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                alert('Please enter a valid email address.');
                return;
            }
            
            alert(`Thank you ${name}! Your application has been submitted successfully.`);
            this.reset();
        });
    }
}

function initRequestServiceValidation() {
    const serviceForm = document.querySelector('.service-form');
    
    if (serviceForm) {
        serviceForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const serviceNameInput = document.querySelector('input[name="service-name"]');
            const nameInput = document.querySelector('input[name="customer-name"]');
            const dueDateInput = document.querySelector('input[name="due-date"]');
            const descriptionInput = document.querySelector('textarea[name="request-description"]');
            
            if (!serviceNameInput || !nameInput || !dueDateInput || !descriptionInput) return;
            
            const serviceName = serviceNameInput.value.trim();
            const name = nameInput.value.trim();
            const dueDate = dueDateInput.value;
            const description = descriptionInput.value.trim();
            
            let errors = [];
            
            if (!serviceName) {
                errors.push('Service Name is required');
            } else if (/^\d/.test(serviceName)) {
                errors.push('Service Name cannot start with numbers.');
            }
            
            if (!name) {
                errors.push('Full Name is required');
            } else if (!/^[a-zA-Z\u0600-\u06FF\s]+$/.test(name)) {
                errors.push('Full Name should contain only letters and spaces');
            } else if (name.split(' ').length < 2) {
                errors.push('Please enter your full name (at least two words)');
            }
            
            if (!dueDate) {
                errors.push('Due date is required');
            } else {
                const due = new Date(dueDate);
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                
                if (due < today) {
                    errors.push('Due date cannot be in the past');
                } else {
                    const diffTime = due - today;
                    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                    
                    if (diffDays < 3) {
                        errors.push('Due date should be at least 3 days from today');
                    }
                }
            }
            
            if (!description) {
                errors.push('Description is required');
            } else if (description.length < 100) {
                errors.push(`Request description is too short; minimum 100 characters (${description.length} entered).`);
            }
            
            if (errors.length > 0) {
                alert('Please fix the following errors:\n' + errors.join('\n'));
                return;
            }
            
            const stay = confirm(`Request submitted successfully!\n\nService: ${serviceName}\nCustomer: ${name}\nDue Date: ${dueDate}\nDescription: ${description.substring(0, 50)}...\n\nDo you want to stay on this page to add another request, or return to the dashboard? (Press OK to Stay, Cancel to go to Dashboard)`);
            
            if (stay) {
                displayRequest(serviceName, name, dueDate, description);
            } else {
                window.location.href = 'customer-dashboard.html';
            }
            
            this.reset();
        });
    }
}

function displayRequest(serviceName, customerName, dueDate, description) {
    let requestsContainer = document.getElementById('requests-container');
    
    if (!requestsContainer) {
        requestsContainer = createRequestsContainer(); 
    }
    
    if (requestsContainer) {
        requestsContainer.style.display = 'block';
        
        const requestDiv = document.createElement('div');
        requestDiv.className = 'request-item';
        requestDiv.innerHTML = `
            <strong>Service Name:</strong> ${serviceName}<br>
            <strong>Customer Name:</strong> ${customerName}<br>
            <strong>Due Date:</strong> ${dueDate}<br>
            <strong>Description:</strong> ${description.substring(0, 100)}...
        `;
        
        requestsContainer.insertBefore(requestDiv, requestsContainer.childNodes[1]); 
    }
}

function createRequestsContainer() {
    const container = document.createElement('div');
    container.id = 'requests-container';
    container.style.marginTop = '20px';
    container.style.padding = '15px';
    container.style.border = '1px solid #e5e7eb';
    container.style.borderRadius = '8px';
    container.style.background = '#f9fafb';
    
    const heading = document.createElement('h3');
    heading.textContent = 'Recent Requests';
    heading.style.marginBottom = '15px';
    heading.style.color = '#374151';
    container.appendChild(heading);
    
    const form = document.querySelector('.service-form');
    if (form) {
        form.parentNode.insertBefore(container, form.nextSibling);
    }
    
    return container;
}


function initServiceManagement() {
    const addServiceForm = document.getElementById('add-service-form');
    
    if (addServiceForm) {
        addServiceForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const serviceNameInput = this.querySelector('input[name="service_name"]');
            const priceInput = this.querySelector('input[name="price"]');
            const descriptionInput = this.querySelector('textarea[name="description"]');
            const photoInput = this.querySelector('input[name="photo"]');

            if (!serviceNameInput || !priceInput || !descriptionInput || !photoInput) return;
            
            const serviceName = serviceNameInput.value.trim();
            const price = priceInput.value.trim();
            const description = descriptionInput.value.trim();
            const photoFile = photoInput.files[0];
            
            let errors = [];
            
            if (!serviceName) errors.push('Service Name is required.');
            if (!price) errors.push('Price is required.');
            if (!description) errors.push('Description is required.');
            if (!photoFile) errors.push('Photo is required.');

            if (serviceName && /^\d/.test(serviceName)) {
                errors.push('Service name cannot start with numbers.');
            }
            
            if (price) {
                 if (isNaN(price) || parseFloat(price) <= 0) {
                    errors.push('Price must be a valid positive number.');
                }
            }

             if (photoFile && !photoFile.type.startsWith('image/')) {
                errors.push('Please upload an image file for the service photo.');
            }
            
            if (errors.length > 0) {
                alert('Please fix the following errors:\n' + errors.join('\n'));
                return;
            }
            
            const service = {
                id: Date.now(),
                name: serviceName,
                price: parseFloat(price),
                description: description,
                date: new Date().toLocaleDateString()
            };
            
            saveService(service);
            
            alert(`Service "${serviceName}" has been added successfully!`);
            
            this.reset();
            
            displayServicesInDashboard();
        });
    }
    
    displayServicesInDashboard();
}

function saveService(service) {
    let services = JSON.parse(localStorage.getItem('services')) || [];
    services.push(service);
    localStorage.setItem('services', JSON.stringify(services));
}

function displayServicesInDashboard() {
    const services = JSON.parse(localStorage.getItem('services')) || [];
    
    const servicesContainerAddPage = document.getElementById('services-list');
    const servicesContainerDashboard = document.getElementById('services-container');
    
    const container = servicesContainerAddPage || servicesContainerDashboard;
    
    if (container) {
        if (services.length === 0) {
            container.innerHTML = '<p class="subtle" style="text-align:center;">No services added yet.</p>';
        } else {
            container.innerHTML = services.map(service => `
                <div class="service-item">
                    <h4>${service.name}</h4>
                    <p><strong>Price:</strong> ${service.price.toFixed(2)} SAR</p>
                    <p>${service.description.substring(0, 100)}...</p>
                    <small><strong>Added:</strong> ${service.date}</small>
                </div>
            `).join('');
        }
    }
}


function getStaffMembers() {
    let members = JSON.parse(localStorage.getItem('staffMembers'));
    
    if (!members || members.length === 0) {
        members = [
            { id: 1, name: "Reema Alsaud", avatar: "reema.jpg", email: "reema@findout.com", expertise: "Software Engineering" },
            { id: 2, name: "Badryah Aljabri", avatar: "badryah.jpg", email: "badryah@findout.com", expertise: "Data Science" },
            { id: 3, name: "Maryam Almazayd", avatar: "mariam.jpg", email: "maryam@findout.com", expertise: "UI/UX Design" }
        ];
        localStorage.setItem('staffMembers', JSON.stringify(members));
    }
    
    return members;
}

function renderStaffMembers() {
    const members = getStaffMembers();
    const container = document.getElementById('delete-members-form');
    
    if (!container) return;
    
    const existingMembers = container.querySelectorAll('.member');
    existingMembers.forEach(member => member.remove());
    
    const deleteButtonContainer = container.querySelector('.center');
    
    members.forEach(member => {
        const memberDiv = document.createElement('div');
        memberDiv.className = 'member';
        memberDiv.setAttribute('data-member-id', member.id);
        
        memberDiv.innerHTML = `
          <input type="checkbox" name="member-check" value="${member.id}" class="member-check">
          <div class="avatar"><img src="${member.avatar || 'default-avatar.jpg'}" alt="${member.name} Photo" /></div>
          <div class="name">${member.name}</div>
        `;
        
        if (deleteButtonContainer) {
            container.insertBefore(memberDiv, deleteButtonContainer);
        } else {
            container.appendChild(memberDiv); 
        }
    });
}

function initStaffManagement() {
    if (document.getElementById('delete-members-form')) {
        renderStaffMembers();
    }
    
    const deleteMembersForm = document.getElementById('delete-members-form');
    const addMemberForm = document.getElementById('add-member-form');
    
    if (deleteMembersForm) {
        deleteMembersForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const selectedMembers = this.querySelectorAll('input[name="member-check"]:checked');
            
            if (selectedMembers.length === 0) {
                alert('Please select at least one member to delete.'); 
                return;
            }
            
            if (confirm(`Are you sure you want to delete ${selectedMembers.length} member(s)?`)) {
                let members = getStaffMembers();
                const selectedIds = Array.from(selectedMembers).map(box => parseInt(box.value));
                
                members = members.filter(member => !selectedIds.includes(member.id));
                
                localStorage.setItem('staffMembers', JSON.stringify(members));
                
                renderStaffMembers();
                
                alert('Selected members have been successfully deleted.');
            }
        });
    }
    
    if (addMemberForm) {
        addMemberForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const nameInput = this.querySelector('input[name="name"]');
            const emailInput = this.querySelector('input[name="email"]');
            const expertiseSelect = this.querySelector('select[name="expertise"]');
            const dobInput = this.querySelector('input[name="dob"]');
            const educationInput = this.querySelector('input[name="education"]');
            const skillsInput = this.querySelector('input[name="skills"]');
            const photoInput = this.querySelector('input[name="photo"]');
            
            
            const name = nameInput.value.trim();
            const email = emailInput.value.trim();
            const expertise = expertiseSelect.value;
            const dob = dobInput.value;
            const education = educationInput.value.trim();
            const skills = skillsInput.value.trim();
            const photoFile = photoInput.files[0];
            
            let errors = [];
            
            if (!name) errors.push('Full Name is required');
            if (!email) errors.push('Email is required');
            if (expertise === '' || expertise === 'Select expertise...') errors.push('Area of Expertise is required');
            if (!dob) errors.push('Date of Birth is required');
            if (!education) errors.push('Education is required');
            if (!skills) errors.push('Skills are required');
            if (!photoFile) errors.push('Photo is required');
            
            if (errors.length > 0) {
                alert('Please fix the following errors:\n' + errors.join('\n')); 
                return;
            }
            
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                alert('Please enter a valid email address.');
                return;
            }
            
            if (/^\d/.test(name)) {
                alert('Name cannot start with numbers.');
                return;
            }
            
             if (photoFile && !photoFile.type.startsWith('image/')) {
                alert('Please upload an image file for the member photo.');
                return;
            }
            
            const newMember = {
                id: Date.now(), 
                name: name,
                avatar: photoFile ? photoFile.name : 'default-avatar.jpg', 
                email: email,
                expertise: expertise,
                dob: dob,
                education: education,
                skills: skills
            };
            
            let members = getStaffMembers();
            members.push(newMember);
            localStorage.setItem('staffMembers', JSON.stringify(members));
            
            renderStaffMembers();
            
            alert(`Member ${name} added successfully!`);
            this.reset();
        });
    }
}
function initServiceEvaluation() {
    const evaluationForm = document.querySelector('form.service-evaluation');
    
    if (evaluationForm) {
        evaluationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const serviceSelect = document.querySelector('select[name="service"]');
            const ratingInputs = document.querySelectorAll('input[name="rating"]');
            const feedbackInput = document.querySelector('textarea[name="feedback"]');
            
            let errors = [];
            
            if (!serviceSelect || serviceSelect.value === '') {
                errors.push('Please select a service');
            }
            
            let ratingSelected = false;
            ratingInputs.forEach(input => {
                if (input.checked) ratingSelected = true;
            });
            
            if (!ratingSelected) {
                errors.push('Please select a rating');
            }
            
            if (!feedbackInput || !feedbackInput.value.trim()) {
                errors.push('Please provide feedback');
            }
            
            if (errors.length > 0) {
                alert('Please fix the following errors:\n' + errors.join('\n'));
                return;
            }
            
            let rating = 0;
            ratingInputs.forEach(input => {
                if (input.checked) rating = parseInt(input.value);
            });
            
            if (rating >= 4) {
                alert('Thank you for your positive feedback! We appreciate your business.');
            } else {
                alert('We apologize for any inconvenience. We will work to improve our service.');
            }
            
            setTimeout(() => {
               
                this.reset();
            }, 2000);
        });
    }
}

function initSearchFunctionality() {
    const searchInput = document.querySelector('.search-box input');
    const activityCards = document.querySelectorAll('.activity-cards .activity-card');
    
    if (searchInput && activityCards.length > 0) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            
            activityCards.forEach(card => {
                const title = card.querySelector('h3').textContent.toLowerCase();
                const description = card.querySelector('p').textContent.toLowerCase();
                
                if (title.includes(searchTerm) || description.includes(searchTerm)) {
                    card.style.display = 'block'; 
                } else {
                    card.style.display = 'none'; 
                }
            });
        });
    }
}

function initLoadMore() {
    const loadMoreBtn = document.querySelector('.load-more');
    
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            alert('Load more functionality would be implemented here with dynamic content loading.');
        });
    }
}

document.addEventListener('DOMContentLoaded', function() {
    console.log('Initializing FindOut website functionality...');
    
    initThemes();
    initBackToTop();
    initRealTimeClock();
    initServicesSorting();
    initJoinTeamValidation();
    initRequestServiceValidation();
    initServiceManagement();
    initStaffManagement();
    initServiceEvaluation();
    initSearchFunctionality();
    initLoadMore();
    
    console.log('All functionalities initialized successfully!');
});

function formatDate(date) {
    return new Date(date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function validateEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}


function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
        color: white;
        border-radius: 8px;
        z-index: 10000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}